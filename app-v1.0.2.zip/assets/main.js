/* global ZAFClient */
const client = ZAFClient.init();
client.invoke("resize", { width: "100%", height: "550px" });

// ==========================================
// DOM ELEMENTS
// ==========================================
const settingsToggle = document.getElementById("settings-toggle");
const settingsChevron = document.getElementById("settings-chevron");
const settingsPanel = document.getElementById("settings-panel");
const mainContainer = document.querySelector(".main-container");

const btnGenerate = document.getElementById("btn-generate");
const btnInsert = document.getElementById("btn-insert");
const btnAttach = document.getElementById("btn-attach-context");
const btnAddUrl = document.getElementById("btn-add-url");

const inputInstruction = document.getElementById("ai-custom-instruction");
const inputContextFile = document.getElementById("context-file-input");
const inputKbFile = document.getElementById("kb-file-input");
const inputKbUrl = document.getElementById("kb-url-input");
const dropZone = document.getElementById("kb-drop-zone");

const outputArea = document.getElementById("ai-output");
const loadingIndicator = document.getElementById("loading-indicator");
const resultArea = document.getElementById("result-area");
const kbStatus = document.getElementById("kb-upload-status");
const contextFileName = document.getElementById("context-file-name");

// ==========================================
// EVENT LISTENERS
// ==========================================

// 1. Toggle Settings
settingsToggle.addEventListener("click", () => {
    const isHidden = settingsPanel.style.display === "none";
    settingsPanel.style.display = isHidden ? "block" : "none";
    
    // Rotate Chevron
    if (isHidden) {
        settingsChevron.classList.add("open");
    } else {
        settingsChevron.classList.remove("open");
    }
});

// 2. Attach Context File (Click Trigger)
btnAttach.addEventListener("click", () => {
    inputContextFile.click();
});

inputContextFile.addEventListener("change", (e) => {
    if (e.target.files.length > 0) {
        contextFileName.textContent = e.target.files[0].name;
    }
});

// 3. KB: Drag & Drop
dropZone.addEventListener("click", () => inputKbFile.click());
dropZone.addEventListener("dragover", (e) => {
    e.preventDefault();
    dropZone.style.borderColor = "#1f73b7";
});
dropZone.addEventListener("dragleave", () => {
    dropZone.style.borderColor = "#c2c8cc";
});
dropZone.addEventListener("drop", (e) => {
    e.preventDefault();
    dropZone.style.borderColor = "#c2c8cc";
    if (e.dataTransfer.files.length > 0) {
        handleKbUpload(e.dataTransfer.files[0]);
    }
});
inputKbFile.addEventListener("change", (e) => {
    if (e.target.files.length > 0) {
        handleKbUpload(e.target.files[0]);
    }
});

// 4. KB: Add URL
btnAddUrl.addEventListener("click", () => {
    const url = inputKbUrl.value.trim();
    if (url) handleKbUrl(url);
});

// 5. Generate Reply
btnGenerate.addEventListener("click", async () => {
    setLoading(true);
    
    try {
        // A. Get Ticket Context
        const data = await client.get('ticket.comments');
        const comments = data['ticket.comments'];
        const ticketContent = comments.slice(-3).map(c => 
            `[${c.author.name}]: ${c.value.replace(/<[^>]*>?/gm, '')}`
        ).join("\n\n");

        // B. Get User Inputs
        const instruction = inputInstruction.value.trim();
        let fileContent = null;

        // C. Read Attached File (if any)
        if (inputContextFile.files.length > 0) {
            fileContent = await readFileAsText(inputContextFile.files[0]);
        }

        // D. Call Backend API
        const meta = await client.metadata();
        const baseUrl = meta.settings.api_endpoint ? String(meta.settings.api_endpoint).replace(/\/+$/, "") : "";

        // MOCK MODE CHECK
        if (!baseUrl || baseUrl.includes("your-vercel-app")) {
            await mockResponse();
            return;
        }

        const resp = await client.request({
            url: `${baseUrl}/api/ai-reply`,
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                ticketContent,
                customInstruction: instruction,
                fileContext: fileContent
            })
        });

        if (resp && resp.reply) {
            outputArea.value = resp.reply;
            resultArea.style.display = "block";
        } else {
            alert("Failed to generate reply.");
        }

    } catch (err) {
        console.error(err);
        alert("Error: " + err.message);
    } finally {
        setLoading(false);
    }
});

// 6. Insert Reply
btnInsert.addEventListener("click", () => {
    client.invoke('ticket.editor.insert', outputArea.value);
});

// ==========================================
// HELPER FUNCTIONS
// ==========================================

async function handleKbUpload(file) {
    kbStatus.textContent = `Uploading ${file.name}...`;
    
    try {
        const text = await readFileAsText(file);
        const meta = await client.metadata();
        const baseUrl = meta.settings.api_endpoint ? String(meta.settings.api_endpoint).replace(/\/+$/, "") : "";

        if (!baseUrl || baseUrl.includes("your-vercel-app")) {
             kbStatus.textContent = "Mock Upload Complete (Set API URL to really save)";
             return;
        }

        await client.request({
            url: `${baseUrl}/api/ingest`,
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                type: 'file',
                name: file.name,
                content: text
            })
        });
        kbStatus.textContent = "Upload successful! Added to Knowledge Base.";
    } catch (err) {
        kbStatus.textContent = "Error: " + err.message;
    }
}

async function handleKbUrl(url) {
    kbStatus.textContent = `Scraping ${url}...`;
    // Similar logic to upload, but sending URL type
    // Implementation omitted for brevity, follows same pattern as upload
}

function readFileAsText(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsText(file);
    });
}

function setLoading(isLoading) {
    loadingIndicator.style.display = isLoading ? "block" : "none";
    resultArea.style.display = isLoading ? "none" : (resultArea.style.display === "block" ? "block" : "none");
    btnGenerate.disabled = isLoading;
}

async function mockResponse() {
    await new Promise(r => setTimeout(r, 2000));
    outputArea.value = `[MOCK REPLY]\n\nDear Customer,\n\nThank you for reaching out. Based on your request and our knowledge base, here is the draft reply...\n\n(Configure the API Endpoint to get real AI replies)`;
    resultArea.style.display = "block";
    setLoading(false);
}
